
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.friendsmod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.block.Block;

import net.mcreator.friendsmod.block.VirticalSlabBlock;
import net.mcreator.friendsmod.block.TableBlock;
import net.mcreator.friendsmod.FriendsModMod;

public class FriendsModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, FriendsModMod.MODID);
	public static final RegistryObject<Block> TABLE = REGISTRY.register("table", () -> new TableBlock());
	public static final RegistryObject<Block> VIRTICAL_SLAB = REGISTRY.register("virtical_slab", () -> new VirticalSlabBlock());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class ClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			VirticalSlabBlock.registerRenderLayer();
		}
	}
}
